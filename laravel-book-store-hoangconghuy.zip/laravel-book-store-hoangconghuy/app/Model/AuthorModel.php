<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AuthorModel extends Model
{
    protected $table = 'authors';
    public function book(){
        return $this->hasMany('App\Model\AuthorBookModel');
    }
}
