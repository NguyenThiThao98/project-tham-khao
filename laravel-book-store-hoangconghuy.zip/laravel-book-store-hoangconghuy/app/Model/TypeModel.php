<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TypeModel extends Model
{
    protected $table = 'types';
    public function book(){
        return $this->hasMany('App\Model\TypeBookModel');
    }
}
