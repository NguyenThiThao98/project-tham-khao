<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AttributeValueModel extends Model
{
    protected $table = 'attribute_value';
    public function attribute(){
        return $this->belongsTo('App\Model\AttributeModel');
    }
    public function book(){
        return $this->hasMany('App\Model\BookAttributeModel');
    }
}
