<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TypeBookModel extends Model
{
    protected $table = 'type_book';
    public function book(){
        return $this->belongsTo('App\Model\BookModel');
    }
    public function type(){
        return $this->belongsTo('App\Model\TypeModel');
    }
}
