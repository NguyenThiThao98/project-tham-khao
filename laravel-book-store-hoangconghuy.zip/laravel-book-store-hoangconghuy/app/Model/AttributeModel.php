<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AttributeModel extends Model
{
    protected $table = 'attributes';
    public function attribute_value(){
        return $this->hasMany('App\Model\AttributeValueModel');
    }
    
}
