<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BookAttributeModel extends Model
{
    protected $table = 'book_attribute';
    public function book(){
        return $this->belongsTo('App\Model\BookModel');
    }
    public function attribute_value(){
        return $this->belongsTo('App\Model\AttributeValueModel');
    }
}
