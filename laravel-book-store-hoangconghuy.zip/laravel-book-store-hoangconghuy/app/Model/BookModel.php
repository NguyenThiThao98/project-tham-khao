<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BookModel extends Model
{
    protected $table = 'books';
    public function author(){
        return $this->hasMany('App\Model\AuthorBookModel');
    }
    public function type(){
        return $this->hasMany('App\Model\TypeBookModel');
    }
    public function attribute(){
        return $this->hasMany('App\Model\BookAttributeModel');
    }
}
