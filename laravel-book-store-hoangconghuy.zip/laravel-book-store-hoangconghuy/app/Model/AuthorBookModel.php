<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AuthorBookModel extends Model
{
    protected $table = 'author_book';
    public function book(){
        return $this->belongsTo('App\Model\BookModel');
    }
    public function author(){
        return $this->belongsTo('App\Model\AuthorModel');
    }
}
