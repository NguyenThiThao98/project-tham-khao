# Project: Book Store

##### Mô tả dự án
- Sử dụng laravel bản mới nhất, Mysql 5.x.
- Tạo ứng dụng quản lý sách. (Có thể nâng cấp thành website thương mại điện tử - Bán sách)
- Admin sẽ thêm, xóa, sửa một bảng các thuộc tính cho đối tượng cần quản lý (book). Nghĩa là: các thuộc tính sẽ không cố định trong DB. Cần tìm hiểu khái niệm EAV (Entity - Attribute - Value) để thiết kế DB.
- Admin (Publisher - người bán sách): có quyền upload sách lên để bán. File sách điện tử là PDF.
- Hệ thống hiển thị danh sách các books, và cho phép filter để tìm kiếm, hoặc search các từ khóa liên quan.
- Hệ thống hiển thị thông tin chi tiết sách, các box: like, share, v...

##### Các module chính:
  + Quản lý admin, vs các quyền:
    + Cấu hình hệ thống
    + Tạo và chỉnh sửa thông tin sản phẩm, nhóm sản phẩm, thuộc tính sản phẩm.
    + Xuất (export) các thống kê báo cáo dạng CSV (Excel), về các data trong hệ thống.
  
  + Quản lý người dùng, vs các quyền:
    + Người dùng chưa đăng nhập chỉ xem.
    + Người dùng đã đăng nhập có quyền upload sản phẩm của cá nhân lên.
  
  + Sản phẩm (sách)
    + Thêm, xóa, sửa: 1 cuốn sách 
    + Thêm, xóa, sửa các thuộc tính của 1 cuốn sách
    + Thêm, xóa, sửa (NHIỀU cuôn sách) thông qua import file CSV (Excel).
  
  + Hiển thị danh sách sản phẩm
    + Có 2 chế độ hiển thị list view (1 sản phảm / dòng); và grid view (3 sản phẩm / dòng).
    + Filter (lọc) tìm kiếm sản phẩm theo các thuộc tính sản phẩm ( có thể kết hợp thuộc tính vs điều kiện AND hoặc OR).
  
  + Hiển thị thông tin chi tiết 1 sản phẩm
    + Hiển thị box comments cho sản phẩm
    + Hiển thị box sản phẩm liên quan (tính năng nâng cao)
    + Hiển thị box sản phẩm đã từng xem (tính năng nâng cao)
    + Hiển thị box tương tác (like, share)

##### Các luồng xử lý đặc biệt
  + Khi tạo, sửa 1 sách:
    + Sửa dụng module php ImageMagick để extract 5 trang đầu tiên  của mỗi file PDF, làm ảnh đại diện (thumbnails) cho mỗi cuốn sách.
    + Lấy các thông tin về sách như số trang, size (Mb).

  + Quản lý thuộc tính sách bằng kiến trúc EAV. Đây là cách tổ chức DB của hệ thống thương mại điện tử Magento.

##### Yêu cầu với thực tập sinh  
  + Đọc, hiểu tài liệu và thiết kế database.
  + Viết các flowchart cho các luồng xử lý chính
  + Làm việc theo team (2 người), phối hợp để hoàn thành công việc.
  + Khi code, chú ý sau: 
    + chia nhỏ các xử lý thành các module, 
    + chia module thành các class theo chức năng nhiệm vụ, 
    + viết các interface, abstract để tạo sự ràng buộc, mô hình hóa hệ thống    

##### Những kỹ thuật cần tìm hiểu thêm
  + ImageMagic
  + DI - Dependency Injection - Design pattern

##### Các bài blog nên đọc
  + Serie [Laravel Beauty: Recipes & Best Practices - Viblo](https://viblo.asia/p/laravel-beauty-recipes-best-practices-6BAMYk9Evnjz)
  + [Giải thích về EAV](https://techblog.vn/boc-me-cach-magento-to-chuc-thiet-ke-san-pham)  
  + [Imagick trong PHP](https://kipalog.com/posts/Imagick-trong-PHP)
  + [Giới thiệu thư viện ImageMagick trong ngôn ngữ PHP - Viblo](https://viblo.asia/p/gioi-thieu-thu-vien-imagemagick-trong-ngon-ngu-php-pDljMbNOMVZn)

##### Bổ sung
  + Trong khoảng thời gian thực tập ngắn, có thể các em chưa hoàn thành được project này. Tuy nhiên, hãy làm tốt nhất, chỉnh chu nhất từng module một.

> Chúc các em học được những kiến thức bổ ích và kinh nghiệm làm việc nhóm!